%% Roe method for the Euler equations

%
    close all; clear ;


% Define computational grid for M = 64 and lambda = 0.5
    M = 512    ;   dx = 4/(M-1) ;    x_j = linspace(-2,2,M) ; 
    T =1.2 ;
    N = 2300 ;   dt = T/N  ;
    

% Initial condtions

    % Gamma
    gam = 1.4 ;

    % Define initial conditions and BCs for u, rho and p.
    u0   = [0*ones(1,M/2) 0*ones(1,M/2)] ;
    rho0 = [3*ones(1,M/2) ones(1,M/2)] ;
    p0   = [3*ones(1,M/2) ones(1,M/2)] ;
    uBL = 0; uBR = 0;
    rhoBL = 3; rhoBR = 1;
    pBL = 3; pBR = 1;
    
    % Compute intial conditions and BCs for E using the equation of state
    E0 = p0./(gam - 1) + rho0.*u0.^2 ;
    EBL = pBL/(gam-1) + rhoBL*uBL^2 ;
    EBR = pBR/(gam-1) + rhoBR*uBR^2 ;
    ymax = max(rho0);
    ymin = min(rho0);
    % Initialize data
    u = u0;
    rho = rho0;
    p = p0;
    E = E0;       
    
    F = @(rho,u,p,E) [rho.*u ; rho.*u.^2 + p ; (E + p).*u ] ;
    
    % Initialize Index and Error
       Index = 0;
       Error1 = 0;
       ErrorInf = 0;     
    for k=1:N ;  
        t = k*dt;
        
        % Append the right BCs to the variables
        rho = [rho rhoBR] ;
        u   = [u   uBR];
        p   = [p   pBR];
        E   = [E   EBR];
        
        % Initialize the numerical flux
        numf = zeros(3,M+1) ;
          
        % Determine the left and right data and fluxes
        UL = [rhoBL ; rhoBL*uBL ; EBL];
        UR = [rho(1);rho(1)*u(1);E(1)];
        FL = F(rhoBL,uBL,pBL,EBL) ;
        FR = F(rho(1),u(1),p(1),E(1)) ;
        
        % Determine the paramete alpha and choose the correct flux
        alph = (FR - FL)./(UR - UL) ;
        op = alph >= 0;
        numf(:,1) = op.*FL + (1-op).*FR ;
        
        
        for j = 1:M
            
            % Determine the left and right data and fluxes
            UL = [rho(j) ; rho(j)*u(j) ; E(j)];
            UR = [rho(j+1);rho(j+1)*u(j+1);E(j+1)];
            FL = F(rho(j),u(j),p(j),E(j)) ;
            FR = F(rho(j+1),u(j+1),p(j+1),E(j+1)) ;

            % Determine the paramete alpha and choose the correct flux
            alph = (FR - FL)./(UR - UL) ;
            op = alph >= 0;
            numf(:,j+1) = op.*FL + (1-op).*FR ;
                    
        end
        
        % Update the variables using the Godunov method
        Vars = [rho(1:end-1) ; rho(1:end-1).*u(1:end-1) ; E(1:end-1)] ;
        Vars = Vars - dt/dx*(numf(:,2:end) - numf(:,1:end-1)) ;
        
        % Pick out the variables again and update pressure
        rho = Vars(1,:) ; u = Vars(2,:)./rho ; E = Vars(3,:) ;
        p = (gam-1)*(E - 0.5*rho.*u.^2) ;
       
        
        % Visulize at time steps synced with the CLAWPACK output. 
        if mod(k,round((N)/100)) == 0     
                  
            % Create the index for the CLAWPACK file
            tag = num2str(Index) ;
            digits = numel(tag) ;
            while digits < 4
                tag = ['0' tag] ;
                digits = numel(tag) ;
            end
            Index = Index + 1;           
            Claw = importdata(['fort.q' tag])  ;
            
            % Pick off and Interpolate the variables 
            RhoClaw = Claw.data(:,1) ;            
            %uClaw = Claw.data(:,2)./Claw.data(:,1);
            %PClaw = (gam-1)*(Claw.data(:,3)-0.5*(Claw.data(:,2).^2)./Claw.data(:,1)); 
            UI = interp1(x_j,rho,linspace(-2,2,numel(RhoClaw)));
            Error1 = [Error1 norm(RhoClaw-UI',1)] ;
            ErrorInf = [ErrorInf norm(RhoClaw-UI',inf)] ;
            clf
            %Visualize the Solutions
            hold on              
            plot(x_j, rho0, 'b', 'LineWidth', 1)           
            plot(linspace(-2,2,numel(Claw.data(:,1))),RhoClaw,'r','LineWidth',2)             
            plot(x_j, rho, 'ko', 'LineWidth', 1);        
            axis([-2 2 ymin - 0.1  ymax + 0.1])
            xlabel('x','FontSize',20);  ylabel('\rho','FontSize',20)
            title(['Density: Roe Scheme, Time =' num2str(t)],'FontSize',18)
            legend('InitialConditions','ExactSolution','Roe Solution')
            pause(0.00001)
            hold off
        end
        
            
    end    
        
         % Plot the errors
          
            figure(2)
            subplot(2,1,1);                     
            hold on
            plot(linspace(0,N,numel(Error1)),Error1,'bo','LineWidth',1)
            xlabel('Time Step','FontSize',15) ; ylabel('Error','FontSize',15);
            title('1-Norm Error of Density with Roe Scheme Euler with CP Solution','FontSize',15)
            hold off
            subplot(2,1,2);
            hold on
            plot(linspace(0,N,numel(ErrorInf)),ErrorInf,'bo','LineWidth',1)
            xlabel('Time Step','FontSize',15) ; ylabel('Error','FontSize',15);
            title('\infty -Norm Error of Density with Roe Scheme Euler with CP Solution','FontSize',15)
            hold off
        