%% HLLC method for the Euler equations 

%
    close all; clear;
    
% Define computational grid for M = 64 and lambda = 0.5
    M = 512    ;   dx = 2*2/M ;    x_j = linspace(-2,2,M) ; 
    T =1.2 ;
    N = 2300 ;   dt = T/N  ;

% Initial condtions

    % Gamma
    gam = 1.4 ;

    % Define initial conditions for u, rho and p. 
    u0   = [0*ones(1,M/2) 0*ones(1,M/2)] ;
    rho0 = [3*ones(1,M/2) ones(1,M/2)] ;
    p0   = [3*ones(1,M/2) ones(1,M/2)] ;
    uBL = 0; uBR = 0;
    rhoBL = 3; rhoBR = 1;
    pBL = 3; pBR = 1;
    
    
    % Compute intial conditions for E using the equation of state
    E0 = p0./(gam - 1) + rho0.*u0.^2 ;
    EBL = pBL/(gam-1) + rhoBL*uBL^2 ;
    EBR = pBR/(gam-1) + rhoBR*uBR^2 ;
       
    ymax = max(rho0);
    ymin = min(rho0);

    % Initialize data
    u = u0;
    rho = rho0;
    p = p0;
    E = E0;
    
    F = @(rho,u,p,E) [rho.*u ; rho.*u.^2 + p ; (E + p).*u ] ;
    
    % Initialize index and Error
    Index = 0;
    Error1 = 0;
    ErrorInf = 0;
  for k=1 : N    
        t = k*dt;
        
        % Append the right BCs to the variables
        rho = [rho rhoBR] ;
        u   = [u   uBR];
        p   = [p   pBR];
        E   = [E   EBR];
        
        % Initialize the numerical flux
        numf = zeros(3,M+1) ;
          
        
% First Riemann problem (Left Most cell (ghost cell)):
        % Estimate the star pressure
        aL = sqrt(abs(gam*pBL./rhoBL)) ;
        aR = sqrt(abs(gam*p(1)./rho(1))) ;
        tilrho = 0.5*(rhoBL+rho(1)) ;
        tila   = 0.5*(aL + aR) ;
        pS = max([0, 0.5*(pBL + p(1)) - 0.5*(u(1) - uBL).*tilrho.*tila]) ;       
        % Calculate the various speeds (in partcular the star speed) 
        s = pS <= pBL ;
        qL = s + (1-s).*sqrt(abs(1 + (gam+1)/(2*gam)*(pS./pBL -1))) ;
        SL = uBL - aL.*qL ;
        %SL = uBL - aL ;
        s = pS <= p(1) ;
        qR = s + (1-s).*sqrt(abs(1 + (gam+1)/(2*gam)*(pS./pBR -1))) ;
        SR = u(1) + aR.*qR ;
        %SR = u(1) + aR ;
        SS = (p(1) - pBL +  rhoBL.*uBL.*(SL - uBL) - rho(1).*u(1).*(SR - u(1)))./(rhoBL.*(SL-uBL) - rho(1).*(SR-u(1))) ;
        
        % Compute U star       
        UL  = [rhoBL; rhoBL.*uBL ; EBL ];
        UR = [rho(1) ; rho(1).*u(1) ; E(1)] ;
        
        USR = rho(1).*(SR - u(1))./(SR - SS).*[1 ; SS; E(1)./rho(1)+(SS - u(1)).*(SS + p(1)./(rho(1).*(SR-u(1))))];
        USL = rhoBL.*((SL - uBL)./(SL - SS)).*[1; SS; EBL./rhoBL+(SS - uBL).*(SS + pBL./(rhoBL.*(SL-uBL)))];
        
        % Calculate the flux options
        FL = F(rhoBL,uBL,pBL,EBL) ;
        FR = F(rho(1),u(1),p(1),E(1)) ;
        FSR = FR + SR*(USR - UR) ;
        FSL = FL + SL*(USL - UL) ;
        
        % Calculate the condition vetors for SL,SS and SR
        l = 0 <= SL ; s = 0 <= SS ; r = SR <= 0 ; 
        l = repmat(l,3,1); s = repmat(s,3,1) ; r = repmat(r,3,1) ;
        
        % Pick the right half step flux
        numf(:,1) = (1-s).*(1-r).*l.*FL + s.*(1-l).*(1-r).*FSL ...
                + (1-s).*(1-r).*(FSR) + r.*(1-s).*(1-l).*FR;
            
            

% Now solve the Riemann problem for all other cells
        for j = 1:M 
            
        % Estimate the star pressure
        aL = sqrt(abs(gam*p(j)./rho(j))) ;
        aR = sqrt(abs(gam*p(j+1)./rho(j+1))) ;
        tilrho = 0.5*(rho(j)+rho(j+1)) ;
        tila   = 0.5*(aL + aR) ;
        pS = max([0, 0.5*(p(j) + p(j+1)) - 0.5*(u(j+1) - u(j)).*tilrho.*tila]) ; 
        % Calculate the various speeds (in partcular the star speed)
        s = pS <= p(j) ;
        %qL = s + (1-s).*sqrt(abs(1 + (gam+1)/(2*gam)*(pS./p(j) -1))) ;
        SL = u(j) - aL.*qL ;
        SL = u(j) - aL;
        s = pS <= p(j+1) ;
        qR = s + (1-s).*sqrt(abs(1 + (gam+1)/(2*gam)*(pS./p(j+1) -1))) ;
        SR = u(j+1) + aR.*qR ;
        %SR = u(j+1) + aR ;
        SS = (p(j+1) - p(j) +  rho(j)*u(j)*(SL - u(j)) - rho(j+1)*u(j+1)*(SR - u(j+1)))/(rho(j)*(SL-u(j)) - rho(j+1)*(SR-u(j+1))) ;
              
        % Compute U star
        UL  = [rho(j); rho(j)*u(j) ; E(j) ];
        UR  = [rho(j+1); rho(j+1)*u(j+1) ; E(j+1) ];
        
        USR = rho(j+1).*((SR - u(j+1))./(SR - SS))*[1; SS; E(j+1)./rho(j+1)+(SS - u(j+1)).*(SS + p(j+1)./(rho(j+1).*(SR-u(j+1))))];
        USL = rho(j).*((SL - u(j))./(SL - SS)).*[1; SS; E(j)./rho(j)+(SS - u(j)).*(SS + p(j)./(rho(j).*(SL-u(j))))];
        
        % Calculate the flux options
        FL = F(rho(j),u(j),p(j),E(j)) ;
        FR = F(rho(j+1),u(j+1),p(j+1),E(j+1)) ;
        FSR = FR + SR*(USR - UR) ;
        FSL = FL + SL*(USL - UL) ;
        
        % Calculate the condition vetors for SL,SS and SR
        l = 0 <= SL ; s = 0 <= SS ; r = SR <= 0 ; 
        l = repmat(l,3,1); s = repmat(s,3,1) ; r = repmat(r,3,1) ;
        
        % Pick the right half step flux
        numf(:,j+1) = (1-s).*(1-r).*l.*FL + s.*(1-l).*(1-r).*FSL ...
                + (1-s).*(1-r).*(FSR) + r.*(1-s).*(1-l).*FR;            
            
        end    
% Use the fluxes in the godunov method together with equation of state          
        Vars = [rho(1:end-1) ; rho(1:end-1).*u(1:end-1) ; E(1:end-1) ];
        Vars = Vars - dt./dx.*(numf(:,2:end) - numf(:,1:end-1)) ;
        p = (gam-1)*(E - 0.5*rho.*u.^2) ;
        
% Pick out the variables  
        rho = Vars(1,:) ; u = Vars(2,:)./rho ; E = Vars(3,:) ;
        p = (gam-1)*(E - 0.5*rho.*u.^2) ;

% Reset the BCs
     
        
               
    if mod(k,round((N)/100)) == 0     
                  
            % Create the index for the CLAWPACK file
            tag = num2str(Index) ;
            digits = numel(tag) ;
            while digits < 4
                tag = ['0' tag] ;
                digits = numel(tag) ;
            end
            Index = Index + 1;           
            Claw = importdata(['fort.q' tag])  ;
            
            % Pick off and Interpolate the variables 
            RhoClaw = Claw.data(:,1) ;            
            %uClaw = Claw.data(:,2)./Claw.data(:,1);
            %PClaw = (gam-1)*(Claw.data(:,3)-0.5*(Claw.data(:,2).^2)./Claw.data(:,1)); 
            UI = interp1(x_j,rho,linspace(-2,2,numel(RhoClaw)));
            Error1 = [Error1 norm(RhoClaw-UI',1)] ;
            ErrorInf = [ErrorInf norm(RhoClaw-UI',inf)] ;
            
            clf
            %Visualize the Solutions
            hold on              
            plot(x_j, rho0, 'b', 'LineWidth', 1)             
            plot(linspace(-2,2,numel(Claw.data(:,1))),Claw.data(:,1),'r','LineWidth',2)             
            plot(x_j, rho, 'ko', 'LineWidth', 1); 
            
            axis([-2 2 ymin - 0.1  ymax + 0.1])
            xlabel('x','FontSize',20);  ylabel('\rho','FontSize',20)
            title(['Density: HLLC Scheme, Time =' num2str(t)],'FontSize',18)
            legend('InitialConditions','ExactSolution','HLLC Solution')
            pause(0.00001)
            hold off
        end
        
        
    
  end
     
  % Plot the errors
          
            figure(2)
            subplot(2,1,1);                     
            hold on
            plot(linspace(0,N,numel(Error1)),Error1,'bo','LineWidth',1)
            xlabel('Time Step','FontSize',15) ; ylabel('Error','FontSize',15);
            title('1-Norm Error of Density with HLLC Euler with CP Solution','FontSize',15)
            hold off
            subplot(2,1,2);
            hold on
            plot(linspace(0,N,numel(ErrorInf)),ErrorInf,'bo','LineWidth',1)
            xlabel('Time Step','FontSize',15) ; ylabel('Error','FontSize',15);
            title('\infty -Norm Error of Density with HLLC Euler with CP Solution','FontSize',15)
            hold off