%% Lax Friedrichs Burgers
% Solve u_t + c u_x = 0, periodic on [0, 2 pi] using
% forward differences in time, upstream weighting in space.
%
    close all; clear;
   
% Define computational grid for M = 64 and lambda = 0.5
    M = 256   ;   dx = 1/M ;    x_j = linspace(0,1,M) ; 
    T =  0.6;  N = 1000 ;   dt = T/N  ;

%
% Initial condtions

    %u0  = exp(-4*(x_j-pi).^2);
    u0 = sin(2*pi*x_j) + 0.5;
    uBL = u0(1);
    uBR = u0(end) ;
    %u0 = [ones(1,M/2) zeros(1,M/2)] ;
    
    ymax = 2;
    ymin = -1;

    
    % Define the flux $F$ of the conservations law
    F  = @(u) u.^2/2 ; 
    DF = @(u) u ;
    
    u = u0;
    
    % Initialize the idex and the error of the solution
    Index = 0;
    Error1 = 0;
    ErrorInf = 0;
    figure(1)
    for k=1 : 4*N/4    
        t = k*dt; 
        
        uL = [u(end) u(1:end-1)] ;
        uR = [u(2:end) u(1)] ;
        
        %
        fL = 0.5*(F(uL) + F(u) + dx/dt*(uL - u));
        fR = 0.5*(F(u) + F(uR) + dx/dt*(u - uR));
        
        u = u + dt/dx*(fL-fR) ;
        
        if mod(k,round((N)/30)) == 0
     
           
            % Create the index for the CLAWPACK file
            tag = num2str(Index) ;
            digits = numel(tag) ;
            while digits < 4
                tag = ['0' tag] ;
                digits = numel(tag) ;
            end
            Index = Index + 1;           
            Claw = importdata(['fort.q' tag])  ;
            CU = Claw.data(:,1) ;
            % Interpolate the approximate solution and compate to CP
            UI = interp1(x_j,u,linspace(0,1,numel(CU)));
            Error1 = [Error1 norm(CU-UI',1)] ;
            ErrorInf = [ErrorInf norm(CU-UI',inf)] ;
            
            clf
            hold on
            
            plot(linspace(0,1,numel(CU)),CU,'r','LineWidth',2)            
            plot(x_j, u0, 'b', 'LineWidth', 1)      
            plot(x_j, u, 'ko', 'LineWidth', 1)  
            axis([0 1 ymin   ymax ])
            xlabel('x','FontSize',20);  ylabel('u','FontSize',20) ;
            title(['Invicit Burgers: Lax Friedrichs Scheme, Time =' num2str(t)],'FontSize',18)
            legend('Exact Solution','Initial Condition','Lax Friedrichs Solution')
            hold off
        pause(0.3)
        end
                
       
        
           
    end
    
    % Plot the errors
            clf
            figure(2)
            subplot(2,1,1);                     
            hold on
            plot(linspace(0,N,numel(Error1)),Error1,'bo','LineWidth',2)
            xlabel('Time Step','FontSize',15) ; ylabel('Error','FontSize',15);
            title('1-Norm Error of Lax Friedrichs Burger with CP Solution','FontSize',15)
            hold off
            subplot(2,1,2);
            hold on
            plot(linspace(0,N,numel(ErrorInf)),ErrorInf,'bo','LineWidth',2)
            xlabel('Time Step','FontSize',15) ; ylabel('Error','FontSize',15);
            title('\infty -Norm Error of Lax Friedrichs Burger with CP Solution','FontSize',15)
            hold off
            
    
    